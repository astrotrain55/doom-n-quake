### RealRTCW

- [RealRTCW](https://github.com/wolfetplayer/RealRTCW/releases)
- [Additional Languages Pack](https://www.moddb.com/mods/realrtcw-realism-mod/downloads)

<hr>

[Назад](../../../README.md)
