### RealRTCW

- **Return to Castle Wolfenstein** (2001)

---

- Port: [RealRTCW](https://github.com/wolfetplayer/RealRTCW/releases)
- Rus: [Additional Languages Pack](https://www.moddb.com/mods/realrtcw-realism-mod/downloads)

---

[Назад](../../../README.md)
